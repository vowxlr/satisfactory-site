﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MyHttpServer
{
    public class HttpServer
    {
        private readonly HttpListener _listener;
        private readonly string _urlPrefix;
        private bool _isRunning;

        public HttpServer(Settings settings)
        {
            _listener = new HttpListener();

            // Нормализация пути (убираем лишние слэши)
            string normalizedPath = settings.Server.Path.Trim('/');
            _urlPrefix = $"http://{settings.Server.Host}:{settings.Server.Port}/{normalizedPath}/";

            _listener.Prefixes.Add(_urlPrefix);
        }

        // Логика запуска
        public void Start()
        {
            _isRunning = true;
            _listener.Start();
            Console.WriteLine($"Сервер запущен и слушает: {_urlPrefix}");

            // Запускаем цикл прослушивания в отдельном потоке, 
            // чтобы консоль могла принимать команды (например, 'stop')
            Task.Run(ListenLoop);
        }

        // Логика остановки
        public void Stop()
        {
            _isRunning = false;
            _listener.Stop();
            _listener.Close();
            Console.WriteLine("Сервер корректно остановлен.");
        }

        // Цикл постоянного прослушивания
        private async Task ListenLoop()
        {
            while (_isRunning)
            {
                try
                {
                    // Ожидаем новый запрос
                    var context = await _listener.GetContextAsync();

                    // Обрабатываем запрос (выносим в отдельную задачу, чтобы не блокировать цикл)
                    _ = Task.Run(() => ProcessRequest(context));
                }
                catch (HttpListenerException)
                {
                    // Это исключение возникает при вызове _listener.Stop()
                    break;
                }
                catch (Exception ex)
                {
                    if (_isRunning)
                        Console.WriteLine($"Ошибка прослушивания: {ex.Message}");
                }
            }
        }

        // Обработка одного запроса и возврат HTML-ответа
        private async Task ProcessRequest(HttpListenerContext context)
        {
            HttpListenerResponse response = context.Response;
            try
            {
                string htmlFilePath = "D:\\Ьеь\\ОРИС\\03 сервер\\сервер\\Search (2).html";
                string htmlFileText;

                if (File.Exists(htmlFilePath))
                {
                    htmlFileText = await File.ReadAllTextAsync(htmlFilePath);
                }
                else
                {
                    htmlFileText = "<html><body><h2>404 - Файл search-engine.html не найден</h2></body></html>";
                    response.StatusCode = 404;
                }

                byte[] buffer = Encoding.UTF8.GetBytes(htmlFileText);
                response.ContentLength64 = buffer.Length;

                using Stream output = response.OutputStream;
                await output.WriteAsync(buffer);
                await output.FlushAsync();

                Console.WriteLine("Запрос обработан");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при обработке запроса: {ex.Message}");
            }
            finally
            {
                context.Response.Close();
            }
        }
    }
}